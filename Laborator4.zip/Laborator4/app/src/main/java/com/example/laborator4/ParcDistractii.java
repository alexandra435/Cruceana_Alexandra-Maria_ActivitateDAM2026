package com.example.laborator4;

import android.os.Parcel;
import android.os.Parcelable;

public class ParcDistractii implements Parcelable {

    // 1. Atributele obiectului
    private String nume;
    private int capacitateVizitatori;
    private boolean areAcrobatii;
    private float ratingSiguranta;
    private String tipAcces;

    // 2. Constructorul principal (folosit la crearea obiectului din formular)
    public ParcDistractii(String nume, int capacitateVizitatori, boolean areAcrobatii, float ratingSiguranta, String tipAcces) {
        this.nume = nume;
        this.capacitateVizitatori = capacitateVizitatori;
        this.areAcrobatii = areAcrobatii;
        this.ratingSiguranta = ratingSiguranta;
        this.tipAcces = tipAcces;
    }

    // 3. Constructorul special Parcelable (folosit de Android pentru a "reconstrui" obiectul primit)
    protected ParcDistractii(Parcel in) {
        nume = in.readString();
        capacitateVizitatori = in.readInt();
        areAcrobatii = in.readByte() != 0; // Se citeste boolean (0 = false, 1 = true)
        ratingSiguranta = in.readFloat();
        tipAcces = in.readString();
    }

    // 4.obligatoriu pentru Parcelable
    public static final Creator<ParcDistractii> CREATOR = new Creator<ParcDistractii>() {
        @Override
        public ParcDistractii createFromParcel(Parcel in) {
            return new ParcDistractii(in);
        }

        @Override
        public ParcDistractii[] newArray(int size) {
            return new ParcDistractii[size];
        }
    };

    @Override
    public int describeContents() {
        return 0; // Metoda ceruta de interfata, returneaza 0 in mod obisnuit
    }

    // 5. Metoda care scrie datele in pachetul (Parcel) ce va fi trimis intre activități
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nume);
        dest.writeInt(capacitateVizitatori);
        dest.writeByte((byte) (areAcrobatii ? 1 : 0));
        dest.writeFloat(ratingSiguranta);
        dest.writeString(tipAcces);
    }

    @Override
    public String toString() {
        return "ParcDistractii {\n" +
                "  Nume='" + nume + "'\n" +
                ", Capacitate=" + capacitateVizitatori + "\n" +
                ", Spectacole=" + (areAcrobatii ? "Da" : "Nu") + "\n" +
                ", Rating Siguranță=" + ratingSiguranta + "/5\n" +
                ", Tip Acces='" + tipAcces + "'\n" +
                '}';
    }
}

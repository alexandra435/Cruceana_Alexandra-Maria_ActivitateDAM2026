package com.example.laborator4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class SecondActivity extends AppCompatActivity {

    private EditText etNume, etCapacitate;
    private SwitchCompat switchAcrobatii;
    private Spinner spTipAcces;
    private RatingBar rbSiguranta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // 1. Legatura cu elementele din XML
        etNume = findViewById(R.id.etNume);
        etCapacitate = findViewById(R.id.etCapacitate);
        switchAcrobatii = findViewById(R.id.switchAcrobatii);
        spTipAcces = findViewById(R.id.spTipAcces);
        rbSiguranta = findViewById(R.id.rbSiguranta);
        Button btnSalveaza = findViewById(R.id.btnSalveaza);

        // 2. Populare Spinner
        if (spTipAcces != null) {
            String[] optiuniBilete = {"Standard", "VIP", "Fast Pass", "Abonament Anual"};
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, optiuniBilete);
            spTipAcces.setAdapter(adapter);
        }

        // 3. Acțiune buton Salveaza
        if (btnSalveaza != null) {
            btnSalveaza.setOnClickListener(v -> {
                String nume = etNume != null ? etNume.getText().toString() : "";
                String capStr = etCapacitate != null ? etCapacitate.getText().toString() : "0";
                int capacitate = capStr.isEmpty() ? 0 : Integer.parseInt(capStr);
                boolean areAcrobatii = switchAcrobatii != null && switchAcrobatii.isChecked();
                float rating = rbSiguranta != null ? rbSiguranta.getRating() : 0f;
                String tipAcces = spTipAcces != null ? spTipAcces.getSelectedItem().toString() : "";

                ParcDistractii parc = new ParcDistractii(nume, capacitate, areAcrobatii, rating, tipAcces);

                Intent resultIntent = new Intent();
                resultIntent.putExtra("PARC_KEY", parc);
                setResult(RESULT_OK, resultIntent);
                finish();
            });
        }
    }
}